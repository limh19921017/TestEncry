package cn.xj.tvjoy.ctypt

import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.DESKeySpec
import javax.crypto.spec.IvParameterSpec

/**
 * DES秘钥
 *
 * DES是一种对称加密算法，所谓对称加密算法即：加密和解密使用相同密钥的算法。DES加密算法出自IBM的研究，
 *后来被美国政府正式采用，之后开始广泛流传，但是近些年使用越来越少，因为DES使用56位密钥，以现代计算能力，
 *24小时内即可被破解
 *
 */
class EncrypDES {
    /**
     * input:要加密的内容
     * password：秘钥
     */
    fun encrytor(input: String?,password:String?): ByteArray? {
        val keyFactory = SecretKeyFactory.getInstance("DES")
        val desKeySpec = DESKeySpec(password?.toByteArray())
        val generateKey = keyFactory.generateSecret(desKeySpec)
        val ivParameterSpec = IvParameterSpec(password?.toByteArray())
        //实例cipher
        val cipher = Cipher.getInstance("DES/CBC/PKCS5Padding")
        //初始化cipher
        //配置ivParameterSpec之后长度不能大于8，秘钥长度不能大于8
        cipher?.init(Cipher.ENCRYPT_MODE, generateKey,ivParameterSpec)  //CBC模式需要额外参数
        val byte = input?.toByteArray()
        val result = cipher?.doFinal(byte)
        println("加密后的长度为："+result?.size)
        return result
    }

    /**
     * 解密
     * input:解密内容
     * password:秘钥
     *
     */
    fun decryptor(input: String?,password: String?): ByteArray {
        val keyFactory = SecretKeyFactory.getInstance("DES")
        val desKeySpec = DESKeySpec(password?.toByteArray())
        val generateKey = keyFactory.generateSecret(desKeySpec)
        val ivParameterSpec = IvParameterSpec(password?.toByteArray())
        //实例cipher
        val cipher = Cipher.getInstance("DES/CBC/PKCS5Padding")   //CBC模式需要额外参数
        //初始化cipher
        //配置ivParameterSpec之后长度不能大于8，秘钥长度不能大于8
        cipher.init(Cipher.DECRYPT_MODE, generateKey,ivParameterSpec)
        val bytes = cipher.doFinal(Base64.decode(input!!))
        return bytes
    }
}

fun main(args: Array<String>) {
    val input:String?="做一条有梦想的咸鱼"
    //长度不能大于8
    val password:String?="12345678"
    val encrytor = EncrypDES().encrytor(input,password)
    val result = Base64.encode(encrytor!!)
    println("加密结果为:$result")

    val decryptor = EncrypDES().decryptor(result,password)
    val encode = String(decryptor)
    println("解密后的结果为：$encode")
}