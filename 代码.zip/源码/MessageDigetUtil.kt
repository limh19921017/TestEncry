package cn.xj.tvjoy.ctypt

import java.lang.StringBuilder
import java.security.MessageDigest

object MessageDigetUtil {

    //md5加密
    fun md5(input:String):String{
        val messageDigest = MessageDigest.getInstance("MD5")
        val digest = messageDigest.digest(input.toByteArray())
        val result = toHex(digest)
        println("md5加密后的长度=${result.toByteArray().size}")
        return result
    }

    //sha1
    fun sha1(input: String):String{
        val messageDigest = MessageDigest.getInstance("SHA-1")
        val digest = messageDigest.digest(input.toByteArray())
        //转成十六进制
        val result = toHex(digest)
        println("sha1加密后的长度=${result.toByteArray().size}")
        return result
    }

    fun sha256(input: String):String{
        val messageDigest = MessageDigest.getInstance("SHA-256")
        val digest = messageDigest.digest(input.toByteArray())
        //转成十六进制
        val result = toHex(digest)
        println("sha256加密后的长度为=${result.toByteArray().size}")
        return result
    }

    //转化为十六进制
    fun toHex(byteArray: ByteArray): String {
        val result = with(StringBuilder()) {
            byteArray.forEach {
                val value = it
                val hex = value.toInt() and (0xFF)
                val hexStr = Integer.toHexString(hex)
                if (hexStr.length == 1) {
                    append("0").append(hexStr)
                } else {
                    append(hexStr)
                }
            }
            toString()
        }
        return result
    }

    //泛型函数
    fun <T> singletonList(item:T):List<T>{
        return listOf(item)
    }
}

fun main(args: Array<String>) {
    val input="做一条有梦想的咸鱼"
    val md5 = MessageDigetUtil.md5(input)
    println("md5加密后为=${md5}")

    val sha1 = MessageDigetUtil.sha1(input)
    println("sha1加密后=$sha1")


    val sha256 = MessageDigetUtil.sha256(input)
    println("sha256加密后=$sha256")
    val singletonList = MessageDigetUtil.singletonList<Int>(1)
    println(singletonList.toString())

}