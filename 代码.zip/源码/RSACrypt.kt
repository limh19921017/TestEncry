package cn.xj.tvjoy.ctypt

import java.io.ByteArrayOutputStream
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.PublicKey
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher

class RSACrypt{
    val transformation="RSA"
    val publicKeyStr = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC039jg7sotX4xr+LGdmTWs7TgRGTAiMAINpAX8B1r8qUbiyHpqp4ozlQhOI8ogMM+p1rcDWTvM+8Iwd9laClFUeVYaun+h4XUgIM5nQ1qmTVN3uf1lYZxzf2a8B0pHWxPYDwIyeHj2UEb3Cx5i5NG5cZ24depXP6jPKwyzTTJtEwIDAQAB"
    val privateKeyStr = "MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBALTf2ODuyi1fjGv4sZ2ZNaztOBEZMCIwAg2kBfwHWvypRuLIemqnijOVCE4jyiAwz6nWtwNZO8z7wjB32VoKUVR5Vhq6f6HhdSAgzmdDWqZNU3e5/WVhnHN/ZrwHSkdbE9gPAjJ4ePZQRvcLHmLk0blxnbh16lc/qM8rDLNNMm0TAgMBAAECgYAKlYrAZtjH3O5/pvblzQBaFSuRvJKXfY2xNKbw/5EwdctjG+4l7ZXlvNPWlruONK0COEFPXdpk/Vp4sZqzbSUjHcirJp4NifP+RuJAiAYzqkVT7kPykC9+id4JPsyLmKRt7bLc30vCtdFCADlYW0/vHHxMo5bENQb1ssmWSA9QgQJBAP50eLzPGQRhzeQqcJEDEK1xNqj3bJ2sL5nKi4BpHoORoqjnJkxXOsiunkh2vOLW1Hv/rRvuSv4BPQ61qmJwnNMCQQC1+QA6WuEchcnM/kDof0HAIFJQ6iWdavoLFldSW8Jt5xoWjJ/BBEs2KGnAGFtEPzjGIM5pthqONbUbQLwKW8bBAkB8yYncroPKTly2pMmHlEU9ieQQgSbXPHYrqdU4KFU6mNV4l8OEdNLzUA934iNH66tRFFZE+Fv2rYzQBe+FT0zZAkBR9I8RuRRhkC/Oz0PUclved7AbGRlPyHpMvAcf5Iuwi8DIHxVkDNcC0Tivd0jDd+XN9cCBA676FV43o/QMhkEBAkAVQiJlcrVNJHfG3/94VV3vs8iCwcFiMn14Rij7YqhkpdaY6rEM17Wttc/jowkkJ4bk7mmDJOHWyyPLYhJq4tiV"
    val ENCRYPT_MAX_SIZE=117 //加密：每次加密最大的长度
    val DECRYPT_MAX_SIZE=128 //解密，每次解密的最大长度

    //获取公钥
    fun getPublicKey():PublicKey{
        //字符串转成密钥对对象
        val keyFactory = KeyFactory.getInstance("RSA")
        val publicKey = keyFactory.generatePublic(X509EncodedKeySpec(Base64.decode(publicKeyStr)))
        return publicKey
    }

    //获取私钥
    fun getPrivateKey():PrivateKey{
        //字符串转成秘钥对象
        val keyFactory = KeyFactory.getInstance("RSA")
        val privateKey = keyFactory.generatePrivate(PKCS8EncodedKeySpec(Base64.decode(privateKeyStr)))
        return privateKey
    }

    /**
     * 私钥加密
     * @param input : 明文
     * @param privateKey :私钥
     */
    fun encryptByPrivateKey(input :String,privateKey: PrivateKey):String{
        val byteArray = input.toByteArray()
        //创建cipher
        val cipher = Cipher.getInstance(transformation)
        //初始化cipher
        cipher.init(Cipher.ENCRYPT_MODE,privateKey)
        //加密：分段加密
        var temp:ByteArray?= null
        //当前偏移的位置
        var offset=0
        val baos = ByteArrayOutputStream()
        //加密：分段加密
        while (byteArray.size-offset>0){//没加密完
            //剩余部分大于117
            if(byteArray.size-offset>=ENCRYPT_MAX_SIZE){
                //加密完整的
                temp=cipher.doFinal(byteArray,offset,ENCRYPT_MAX_SIZE)
                //重新计算偏移的位置
                offset+=ENCRYPT_MAX_SIZE
            }else{
                temp=cipher.doFinal(byteArray,offset,byteArray.size-offset)
                offset=byteArray.size
            }
            baos.write(temp)
        }
        baos.close()

        return Base64.encode(baos.toByteArray())
    }

    /**
     * 私钥解密
     * @param input  :明文
     * @param privateKey ：私钥
     */
    fun decryptByPrivateKey(input: String,privateKey: PrivateKey):String{
        val byteArray = Base64.decode(input)
        //创建cipher
        val cipher = Cipher.getInstance(transformation)
        //初始化cipher
        cipher.init(Cipher.DECRYPT_MODE,privateKey)
        //分段解密
        var temp :ByteArray?=null
        val baos = ByteArrayOutputStream()
        var offset=0
        while (byteArray.size-offset>0){
            if(byteArray.size-offset>=DECRYPT_MAX_SIZE){
                //解密完整的
                temp=cipher.doFinal(byteArray,offset,DECRYPT_MAX_SIZE)
                offset+=DECRYPT_MAX_SIZE
            }else{
                temp=cipher.doFinal(byteArray,offset,byteArray.size-offset)
                offset=byteArray.size
            }
            baos.write(temp)
        }
        baos.close()
        return String(baos.toByteArray())
    }

    /**
     * 公钥加密
     * @param  input :输入的明文
     * @param  publicKey :公钥
     */
    fun encryptByblicKey(input: String,publicKey: PublicKey):String{
        val byteArray = input.toByteArray()
        //创建cipher
        val cipher = Cipher.getInstance("RSA")
        //初始化cipher
        cipher.init(Cipher.ENCRYPT_MODE,publicKey)
        //缓冲区
        var temp:ByteArray?=null
        //偏移量
        var offset=0
        val baos = ByteArrayOutputStream()
        //加密：分段解密
        while (byteArray.size-offset>0){
            if(byteArray.size-offset>=ENCRYPT_MAX_SIZE){
                //加密完整的
                temp=cipher.doFinal(byteArray,offset,ENCRYPT_MAX_SIZE)
                //重新计算偏移的位置
                offset+=ENCRYPT_MAX_SIZE
            }else{
                //解密最后一块
                temp=cipher.doFinal(byteArray,offset,byteArray.size-offset)
                //重新计算偏移的位置
                offset=byteArray.size
            }
            baos.write(temp)
        }
        baos.close()
        return Base64.encode(baos.toByteArray())
    }


    /**
     * 公钥解密
     * @param input :明文
     * @param publicKey :公钥
     */
    fun decryptByPublicKey(input: String,publicKey: PublicKey):String{
        val byteArray = Base64.decode(input)
        //创建cipher
        val cipher = Cipher.getInstance("RSA")
        //初始化cipher
        cipher.init(Cipher.DECRYPT_MODE,publicKey)

        //缓冲区
        var temp:ByteArray?=null
        //偏移量
        var offset=0
        val baos = ByteArrayOutputStream()
        //加密：分段加密
        while (byteArray.size-offset>0){ //没解密完
            if(byteArray.size-offset>=DECRYPT_MAX_SIZE){
                //解密完整的
                temp=cipher.doFinal(byteArray,offset,DECRYPT_MAX_SIZE)
                //重新计算偏移的位置
                offset+=DECRYPT_MAX_SIZE
            }else{
                //解密最后一块
                temp=cipher.doFinal(byteArray,offset,byteArray.size-offset)
                //重新计算偏移的位置
                offset=byteArray.size
            }
            baos.write(temp)
        }
        baos.close()
        return String(baos.toByteArray())
    }
}

fun main(args: Array<String>) {
    //生成密钥对
    val keyPairGenerator = KeyPairGenerator.getInstance("RSA")
    val genKeyPair = keyPairGenerator.genKeyPair()
    val publicKey = genKeyPair.public
    val privateKey = genKeyPair.private
    println("公钥为=${Base64.encode(publicKey.encoded)}")
    println("私钥为=${Base64.encode(privateKey.encoded)}")

    val input="做一条有梦想的咸鱼"
//    println(input.length)
//    println(input.toByteArray().size)

    val publicKeyString=Base64.encode(publicKey.encoded)
    val privateKeyString=Base64.encode(privateKey.encoded)
    //字符串转成秘钥对象
    val keyFactory = KeyFactory.getInstance("RSA")
    val publicKey1 = keyFactory.generatePublic(X509EncodedKeySpec(Base64.decode(publicKeyString)))
    val privateKey1 = keyFactory.generatePrivate(PKCS8EncodedKeySpec(Base64.decode(privateKeyString)))

    //RSA加密：公钥加密，只能私钥解密  私钥加密，只能公钥解密

    //私钥加密
    val encryptByPrivateKey = RSACrypt().encryptByPrivateKey(input, privateKey1)
    println("私钥加密=$encryptByPrivateKey")
    //公钥加密
    val encryptByblicKey = RSACrypt().encryptByblicKey(input, publicKey1)
    println("公钥加密=$encryptByblicKey")

    //公钥解密
    val decryptByPublicKey = RSACrypt().decryptByPublicKey(encryptByPrivateKey, publicKey1)
    println("公钥解密=$decryptByPublicKey")
    //私钥解密
    val decryptByPrivateKey = RSACrypt().decryptByPrivateKey(encryptByblicKey, privateKey1)
    println("私钥解密=$decryptByPrivateKey")

}