package cn.xj.tvjoy.ctypt

import java.security.PrivateKey
import java.security.PublicKey
import java.security.Signature

object SignatureDemo{

    //签名
    fun sign(input:String,privateKey: PrivateKey):String{
        //获取数字签名示例对象
        val signature = Signature.getInstance("SHA256withRSA")
        //初始化签名
        signature.initSign(privateKey)
        //设置数据源
        signature.update(input.toByteArray())
        //签名
        val sign = signature.sign()
        return Base64.encode(sign)
    }

    //校验签名信息
    fun verify(input: String,publicKey: PublicKey,sign:String):Boolean{
        //获取实例签名对象
        val signature = Signature.getInstance("SHA256withRSA")
        //初始化签名
        signature.initVerify(publicKey)
        //传入数据源
        signature.update(input.toByteArray())
        //校验
        val verify = signature.verify(Base64.decode(sign))
        return verify
    }
}

fun main(args: Array<String>) {
    val input="name=iPone8&privace=7"
    val privateKey = RSACrypt().getPrivateKey()
    val publicKey = RSACrypt().getPublicKey()

    val sign = SignatureDemo.sign(input, privateKey)
    println("签名后的结果为=$sign")

    val verify = SignatureDemo.verify("name=iPone8&privace=7888", publicKey, sign)
    println("校验结果为=$verify")
}